
import Applicant from "pages/LandingPages/Applicant/Applicant";

export default function AuthorPage() {
  return <Applicant />;
}
